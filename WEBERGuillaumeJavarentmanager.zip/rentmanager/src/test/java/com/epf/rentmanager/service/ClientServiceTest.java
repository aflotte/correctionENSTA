package com.epf.rentmanager.service;

import static org.junit.Assert.assertThrows;
//import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;

@RunWith(MockitoJUnitRunner.class)

public class ClientServiceTest {
	
	@InjectMocks
	private ClientService clientService;
	@Mock
	private ClientDao clientDao;

//	@Test (expected = ServiceException.class)
	@Test
	public void createDuplicateEmailTest() throws DaoException, ServiceException {
		Client client = new Client("tests", "tests", "expected@email.com", LocalDate.parse("11/11/1111", DateTimeFormatter.ofPattern("dd/MM/yyyy")));
		
		long id = -1;
		try{
			id = this.clientService.create(client);
			System.out.println("cdfvgbhn : "+id); // renvoie l'indice 1
			this.clientService.create(client); // ne lève pas exception alors qu'il devrait (empêche la création lorsque utilisé dans l'interface web) je ne sais pas où est mon erreur
		} catch (ServiceException e ) {
			System.out.println("coucou : "+id);
			this.clientService.delete(id);
			assertTrue(true);
		}
		fail();
		// laisse un client "vide" ne correspondant pas aux critères du service dans la base de données à chaque test avec un id cohérent (à la suite des ids précédents)
		
//		this.clientService.create(client); 
//		assertThrows(ServiceException.class, () -> { // laisse un client vide dans le base de donnée à chaque test
//				this.clientService.create(client);
//			});
	}
}
