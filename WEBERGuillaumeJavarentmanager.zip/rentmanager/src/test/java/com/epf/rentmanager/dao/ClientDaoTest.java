package com.epf.rentmanager.dao;

import static org.junit.Assert.assertTrue;

import java.time.LocalDate;

import org.junit.Test;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Client;

public class ClientDaoTest {
	@Test
	public void createShouldThrowExceptionTest() {
		try {
			ClientDao.getInstance().create(new Client("nom", "prenom", "email", LocalDate.of(2000, 01, 01)));
		} catch (DaoException e ) {
			assertTrue(true);
		}
	}
}
