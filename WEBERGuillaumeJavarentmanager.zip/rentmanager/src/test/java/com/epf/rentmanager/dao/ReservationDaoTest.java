package com.epf.rentmanager.dao;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.service.ClientService;

@RunWith(MockitoJUnitRunner.class)

public class ReservationDaoTest {
	@InjectMocks
	private ClientService clientService;
	@Mock
	private ClientDao clientDao;

	@Test
	void methode() throws DaoException {
		
	}
}
