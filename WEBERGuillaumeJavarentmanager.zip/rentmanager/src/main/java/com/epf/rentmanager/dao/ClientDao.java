package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.persistence.ConnectionManager;

@Repository
public class ClientDao {
	
	private static ClientDao instance = null;
	private ClientDao() {}
	public static ClientDao getInstance() {
		if(instance == null) {
			instance = new ClientDao();
		}
		return instance;
	}
	
	private static final String CREATE_CLIENT_QUERY = "INSERT INTO Client(nom, prenom, email, naissance) VALUES(?, ?, ?, ?);";
	private static final String UPDATE_CLIENT_QUERY = "UPDATE Client SET nom=?, prenom=?, email=?, naissance=? WHERE id=?;";
	private static final String DELETE_CLIENT_QUERY = "DELETE FROM Client WHERE id=?;";
	private static final String FIND_CLIENT_QUERY = "SELECT nom, prenom, email, naissance FROM Client WHERE id=?;";
	private static final String FIND_CLIENTS_QUERY = "SELECT id, nom, prenom, email, naissance FROM Client;";
	private static final String COUNT_CLIENTS = "SELECT COUNT(*) FROM Client;";
	
	public long create(Client client) throws DaoException {
		try (
			
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(CREATE_CLIENT_QUERY, Statement.RETURN_GENERATED_KEYS);
		) {	
			stmt.setString(1, client.getNom());
			stmt.setString(2, client.getPrenom());
			stmt.setString(3, client.getEmail());
			stmt.setDate(4, Date.valueOf(client.getNaissance()));
			
			stmt.executeUpdate();
			ResultSet resultSet = stmt.getGeneratedKeys();
			if (resultSet.next()) {
				if (client.getId() == -1) {
					client.setId(resultSet.getLong(1));
				}
				return resultSet.getLong(1);
			} else {
				throw new DaoException();
			}
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	
	public int delete(Client client) throws DaoException {
		return this.delete(client.getId());
	}
	
	public int delete(long client_id) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(DELETE_CLIENT_QUERY);
		) {	
			stmt.setLong(1, client_id);
			
			return stmt.executeUpdate();
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	public long count() throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(COUNT_CLIENTS);
		) {	
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet.next()) {
				return resultSet.getLong(1);
			} else {
				throw new DaoException();
			}
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	public long update(Client client) throws DaoException {
		try (
				
				Connection connection = ConnectionManager.getConnection();
				PreparedStatement stmt = connection.prepareStatement(UPDATE_CLIENT_QUERY, Statement.RETURN_GENERATED_KEYS);
			) {	
				stmt.setString(1, client.getNom());
				stmt.setString(2, client.getPrenom());
				stmt.setString(3, client.getEmail());
				stmt.setDate(4, Date.valueOf(client.getNaissance()));
				stmt.setLong(5, client.getId());
				
				stmt.executeUpdate();
				ResultSet resultSet = stmt.getGeneratedKeys();
				if (resultSet.next()) {
					if (client.getId() == -1) {
						client.setId(resultSet.getLong(1));
					}
					return resultSet.getLong(1);
				} else {
					throw new DaoException();
				}
			} catch(SQLException e) {
				throw new DaoException();
			}
	}

	public Optional<Client> findById(long id) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(FIND_CLIENT_QUERY);
		) {	
			stmt.setLong(1, id);
			
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet.next()) {
				Client newclient = new Client(resultSet.getString(1), resultSet.getString(2), resultSet.getString(3), resultSet.getDate(4).toLocalDate(), id);
				return Optional.of(newclient);
			} else {
				throw new DaoException();
			}
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}

	public List<Client> findAll() throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(FIND_CLIENTS_QUERY);
		) {	
			
			ResultSet resultSet = stmt.executeQuery();
			
			List<Client> clients = new ArrayList<Client>();
			while (resultSet.next()) {
				clients.add(new Client(resultSet.getString(2), resultSet.getString(3), resultSet.getString(4), resultSet.getDate(5).toLocalDate(), resultSet.getLong(1)));
			}
			return clients;
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}

}
