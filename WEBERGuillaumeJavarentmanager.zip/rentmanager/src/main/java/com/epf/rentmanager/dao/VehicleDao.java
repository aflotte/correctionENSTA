package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.persistence.ConnectionManager;

@Repository
public class VehicleDao {
	
	private static VehicleDao instance = null;
	private VehicleDao() {}
	public static VehicleDao getInstance() {
		if(instance == null) {
			instance = new VehicleDao();
		}
		return instance;
	}
	
	private static final String CREATE_VEHICLE_QUERY = "INSERT INTO Vehicle(constructeur, modele, nb_places) VALUES(?, ?, ?);";
	private static final String UPDATE_VEHICLE_QUERY = "UPDATE Vehicle SET constructeur=?, modele=?, nb_places=? WHERE id=?;";
	private static final String DELETE_VEHICLE_QUERY = "DELETE FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICLE_QUERY = "SELECT id, constructeur, modele, nb_places FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICLES_QUERY = "SELECT id, constructeur, modele, nb_places FROM Vehicle;";
	private static final String COUNT_VEHICLES = "SELECT COUNT(*) FROM Vehicle;";
	
	public long create(Vehicle vehicle) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(CREATE_VEHICLE_QUERY, Statement.RETURN_GENERATED_KEYS);
		) {	
			stmt.setString(1, vehicle.getConstructeur());
			stmt.setString(2, vehicle.getModele());
			stmt.setShort(3, vehicle.getNb_places());
			
			stmt.executeUpdate();
			ResultSet resultSet = stmt.getGeneratedKeys();
			if (resultSet.next()) {
				if (vehicle.getId() == -1) {
					vehicle.setId(resultSet.getLong(1));
				}
				return resultSet.getLong(1);
			} else {
				throw new DaoException();
			}
		} catch(SQLException e) {
			throw new DaoException();
		}
	}

	public int delete(Vehicle vehicle) throws DaoException {
		return delete(vehicle.getId());
	}
	
	public int delete(long vehicle_id) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(DELETE_VEHICLE_QUERY);
		) {	
			stmt.setLong(1, vehicle_id);
			
			return stmt.executeUpdate();
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	public long count() throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(COUNT_VEHICLES);
		) {	
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet.next()) {
				return resultSet.getLong(1);
			} else {
				throw new DaoException();
			}
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	public long update(Vehicle vehicle) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(UPDATE_VEHICLE_QUERY, Statement.RETURN_GENERATED_KEYS);
		) {	
			stmt.setString(1, vehicle.getConstructeur());
			stmt.setString(2, vehicle.getModele());
			stmt.setShort(3, vehicle.getNb_places());
			stmt.setLong(4, vehicle.getId());
			
			stmt.executeUpdate();
			ResultSet resultSet = stmt.getGeneratedKeys();
			if (resultSet.next()) {
				if (vehicle.getId() == -1) {
					vehicle.setId(resultSet.getLong(1));
				}
				return resultSet.getLong(1);
			} else {
				throw new DaoException();
			}
		} catch(SQLException e) {
			throw new DaoException();
		}
	}

	public Optional<Vehicle> findById(long id) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(FIND_VEHICLE_QUERY);
		) {	
			stmt.setLong(1, id);
			
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet.next()) {
				Vehicle vehicle = new Vehicle(resultSet.getString(2), resultSet.getString(3), resultSet.getShort(4), id);
				return Optional.of(vehicle);
			} else {
				throw new DaoException();
			}
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}

	public List<Vehicle> findAll() throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(FIND_VEHICLES_QUERY);
		) {	
			
			ResultSet resultSet = stmt.executeQuery();
			
			List<Vehicle> vehicles = new ArrayList<Vehicle>();
			while (resultSet.next()) {
				vehicles.add(new Vehicle(resultSet.getString(2), resultSet.getString(3), resultSet.getShort(4), resultSet.getLong(1)));
			}
			return vehicles;
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	

}
