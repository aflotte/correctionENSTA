package com.epf.rentmanager.service;

import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.dao.VehicleDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;

@Service
public class ReservationService {
	
	private ReservationDao reservationDao;
	private VehicleService vehicleService;
	private ClientService clientService;
//	public static ReservationService instance;
		
public ReservationService(ReservationDao reservationDao, VehicleService vehicleService, ClientService clientService) {
	this.reservationDao = reservationDao;
	this.vehicleService = vehicleService;
	this.clientService = clientService;
}


//	public static ReservationService getInstance() {
//		if (instance == null) {
//			instance = new ReservationService();
//		}
//		
//		return instance;
//	}
	
	
	public long create(Reservation reservation) throws ServiceException, DaoException {
		testParameters(reservation);
		return reservationDao.create(reservation);
	}
	
	public long count() throws ServiceException, DaoException {
		return reservationDao.count();
	}
	
	public int delete(long id) throws ServiceException, DaoException {
		return reservationDao.delete(id);
	}
	
	public long update(Reservation reservation) throws ServiceException, DaoException {
		testParameters(reservation);
		return reservationDao.update(reservation);
	}

	public List<Reservation> findResaByClientId(long id) throws ServiceException,DaoException {
		return reservationDao.findResaByClientId(id);
	}
	
	public List<Reservation> findResaByVehicleId(long id) throws ServiceException,DaoException {
		return reservationDao.findResaByVehicleId(id);
	}
	
	public Optional<Reservation> findById(long id) throws ServiceException, DaoException {
		return reservationDao.findById(id);
	}

	public List<Reservation> findAll() throws ServiceException, DaoException {
		return reservationDao.findAll();
	}
	
	private void testParameters(Reservation reservation) throws ServiceException, DaoException {
		
		if (reservation.getDebut().compareTo(reservation.getFin()) > 0) {
			throw new ServiceException("begining date is after ending date");
		}
		if (!clientService.findById(reservation.getClient_id()).isPresent()) {//check that client id exists
			throw new ServiceException("the specified client doesn't exist");
		}
		if (!vehicleService.findById(reservation.getVehicle_id()).isPresent()) {//check that client id exists
			throw new ServiceException("the specified vehicle doesn't exist");
		}
		long duree = ChronoUnit.DAYS.between(reservation.getDebut(), reservation.getFin())+1;
//		System.out.println("duree: "+duree);
		if(duree > 7) {
			throw new ServiceException("too long rent : max 7 days");
		}

		List<Reservation> allReservations = reservationDao.findResaByVehicleId(reservation.getVehicle_id());
//		System.out.println(""+allReservations);
		for (Reservation reservations : allReservations) {
			if (reservations.getId()!=reservation.getId() && !(reservation.getDebut().isAfter(reservations.getFin()) || reservation.getFin().isBefore(reservations.getDebut()))) {
				throw new ServiceException("the specified vehicle is not available during this period");
			}
//			System.out.println("durée : "+((duree + ChronoUnit.DAYS.between(reservations.getDebut(),reservations.getFin())) > 7));
//			System.out.println(Math.abs(ChronoUnit.DAYS.between(reservation.getFin(),reservations.getDebut()))==1);
//			System.out.println(Math.abs(ChronoUnit.DAYS.between(reservations.getFin(),reservation.getDebut()))==1);
			
			if(!gapBetween(reservation, reservations)) {
				if(!modeUpdate(reservation, reservations) && (duree + ChronoUnit.DAYS.between(reservations.getDebut(),reservations.getFin())+1) > 7) {
					if(reservation.getClient_id()==reservations.getClient_id()) {
						duree += ChronoUnit.DAYS.between(reservations.getDebut(),reservations.getFin())+1;
						if(duree>7) {
							throw new ServiceException("too long rent : max 7 days");
						}
					}
				}
			}
			
		}
		duree = ChronoUnit.DAYS.between(reservation.getDebut(), reservation.getFin())+1;
		allReservations.add(reservation);
		Collections.sort(allReservations);
		int index = allReservations.indexOf(reservation);
		long daysBetweenReservation;
		for (int i = 1; i >= -1; i-=2) {
			int j = index + i;
			while (true) {
				try {
					if (i>0) {
						daysBetweenReservation = ChronoUnit.DAYS.between(allReservations.get(j-i).getFin(), allReservations.get(j).getDebut());
					} else {
						daysBetweenReservation = ChronoUnit.DAYS.between(allReservations.get(j-i).getDebut(), allReservations.get(j).getFin());
					}
				} catch (IndexOutOfBoundsException e) {
					break;
				}
				if (Math.abs(daysBetweenReservation) >= 2) {
					break;
				} else {
					duree += Math.abs(ChronoUnit.DAYS.between(allReservations.get(j).getDebut(),allReservations.get(j).getFin()))+1;
					if (duree > 30) {
						throw new ServiceException("maximum rent in a row reached : 30 days");
					}
					j+=i;
				}
			}
		}
	}
	private boolean gapBetween(Reservation fixedReservation, Reservation mobilReservation) {
		return !(Math.abs(ChronoUnit.DAYS.between(fixedReservation.getFin(),mobilReservation.getDebut()))==1 || Math.abs(ChronoUnit.DAYS.between(mobilReservation.getFin(),fixedReservation.getDebut()))==1);
	}
	private boolean modeUpdate(Reservation fixedReservation, Reservation mobilReservation) {
		return mobilReservation.getId()==fixedReservation.getId();
	}
}
