package com.epf.rentmanager.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.dao.VehicleDao;

@Service
public class VehicleService {

	private VehicleDao vehicleDao;
	public static VehicleService instance;
	
	private VehicleService(VehicleDao vehicleDao) {
		this.vehicleDao = vehicleDao;
	}
	
	/**    
	 * ajoute un vehicule à la base de données s'il répond aux exigences
	 * @return l'id du vehicule créé
	 * @throwsDaoException s'il ne répond pas aux exigences
	 * @throwsDaoException si l'opération est interdite par la base de données
	 */
	public long create(Vehicle vehicle) throws ServiceException, DaoException {
		CheckVehicleData(vehicle);
		return vehicleDao.create(vehicle);
	}
	
	/**    
	 * modifie le vehicule de la base de données qui a le même id que celui donné s'il répond aux exigences
	 * @return l'id du vehicule modifié
	 * @throwsServiceException s'il ne répond pas aux exigences
	 * @throwsDaoException si l'opération est interdite par la base de données
	 */
	public long update(Vehicle vehicle) throws ServiceException, DaoException {
		CheckVehicleData(vehicle);
		return vehicleDao.update(vehicle);
	}
	
	private void CheckVehicleData(Vehicle vehicle) throws ServiceException, DaoException {
		if (vehicle.getConstructeur().length() >=2) {
			throw new ServiceException("empty constructeur");
		}
		if (vehicle.getModele().length() >=2) {
			throw new ServiceException("empty modele");
		}
		if (vehicle.getNb_places() < 2 || vehicle.getNb_places() > 9) {
			throw new ServiceException("wrong number of seat");
		}
	}
	
	/**    
	 * permet d'obtenir le nombre de vehicule enregistré dans la base de données.
	 * @return le nombre de vehicule dans la base de données
	 * @throwsDaoException si l'opération est interdite par la base de données
	 */
	public long count() throws DaoException {
		return vehicleDao.count();
	}
	
	/**    
	 * supprime le vehicule qui porte l'id donné
	 * @return l'id du vehicule supprimé
	 * @throwsDaoException si l'opération est interdite par la base de données (par exemple : si aucun vehicule n'a l'indice donné)
	 */
	public int delete(long id) throws DaoException {
		return vehicleDao.delete(id);
	}
	
	/**    
	 * retourne le vehicule qui porte l'id donné
	 * @return le vehicule 
	 * @throwsDaoException si l'opération est interdite par la base de données (par exemple : si aucun vehicule n'a l'indice donné)
	 */
	public Optional<Vehicle> findById(long id) throws DaoException {
		return vehicleDao.findById(id);
	}

	public List<Vehicle> findAll() throws ServiceException, DaoException {
		return vehicleDao.findAll();
	}
	
}
