package com.epf.rentmanager.ui.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.service.VehicleService;

@WebServlet("/users/details")
public class ClientDetailServlet extends HttpServlet{
	
	@Autowired
	ClientService clientService;
	@Autowired
	VehicleService vehicleService;
	@Autowired
	ReservationService reservationService;
	@Override
	public void init() throws ServletException {
		super.init();
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/details.jsp");
		try {
			Optional<Client> client = clientService.findById(Long.parseLong(request.getParameter("id")));
			if (client.isPresent()) {
				request.setAttribute("client", client.get());
			}
			List<Reservation> allReservations = reservationService.findResaByClientId(client.get().getId());
			List<Reservation> reservations = reservationService.findResaByClientId(client.get().getId());
			List<Vehicle> allVehicles = vehicleService.findAll();
			List<Vehicle> vehicles = new ArrayList<Vehicle>();
			int nbReservation = allReservations.size();
			for (int i=nbReservation-1; i > -1;i--) {
				boolean vehicleInList = false;
				for (Vehicle vehicle : vehicles) {
					if(vehicle.getId()==allReservations.get(i).getVehicle_id()) {
						vehicleInList=true;
						break;
					}
				}
				if (!vehicleInList) {
					for (Vehicle vehicle : allVehicles) {
						if(vehicle.getId()==allReservations.get(i).getVehicle_id()) {
							vehicles.add(vehicle);
							break;
						}
					}
				}
			}
			request.setAttribute("reservations", reservations);
			request.setAttribute("vehicles", vehicles);
			request.setAttribute("nbVehicle", vehicles.size());
			request.setAttribute("nbReservation", reservations.size());
		} catch (final Exception e) {
			dispatcher.forward(request, response);
		}
		
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
