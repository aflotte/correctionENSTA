package com.epf.rentmanager.exception;

public class ServiceException extends Exception{

	public ServiceException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ServiceException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	
}
