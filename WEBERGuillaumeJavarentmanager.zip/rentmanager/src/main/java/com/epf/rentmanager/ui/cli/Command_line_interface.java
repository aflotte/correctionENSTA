package com.epf.rentmanager.ui.cli;

import java.time.LocalDate;
import java.util.Optional;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.epf.rentmanager.configuration.AppConfiguration;
import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.dao.VehicleDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.service.VehicleService;
import com.epf.rentmanager.utils.IOUtils;

public class Command_line_interface {
	
	public static void main(String[] args) {
		
		ApplicationContext context= new AnnotationConfigApplicationContext(AppConfiguration.class);
		ClientService clientService = context.getBean(ClientService.class);
		VehicleService vehicleService = context.getBean(VehicleService.class);
		ReservationService reservationService = context.getBean(ReservationService.class);
		
		while (true) {
			
			IOUtils.print("0 - create");
			IOUtils.print("1 - delete");
			IOUtils.print("2 - find by id");
			IOUtils.print("3 - print all");
			IOUtils.print("4 - quit");
			
			int fnc = IOUtils.readInt("Choose function :");
			
			if (fnc >= 4) {
				System.exit(0);
			}
			
			IOUtils.print("0 - client");
			IOUtils.print("1 - vehicle");
			IOUtils.print("2 - reservation");
			IOUtils.print("3 - quit");
			
			int classe = IOUtils.readInt("Choose class :");
			
			switch (fnc) {
			case 0:
				switch(classe) {
				case 0:
					try {
						IOUtils.print("new client :" + clientService.create(new Client(IOUtils.readString("enter name : ", true), IOUtils.readString("enter first name : ", true), IOUtils.readString("enter email : ", true), IOUtils.readDate("enter date : ", true))));
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					} catch (ServiceException e) {
						IOUtils.print(e.getMessage());
					}
					break;
				case 1:
					try {
						IOUtils.print("new vehicle :" + vehicleService.create(new Vehicle(IOUtils.readString("enter manufacturer : ", true), IOUtils.readString("enter model : ", true), (short) IOUtils.readInt("enter number of seat : "))));
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					} catch (ServiceException e) {
						IOUtils.print(e.getMessage());
					}
					break;
				case 2:
					try {
						IOUtils.print("new reservation :" + reservationService.create(new Reservation(IOUtils.readDate("enter starting date : ", true), IOUtils.readDate("enter ending date : ", true), IOUtils.readInt("enter client id :"), IOUtils.readInt("enter vehicle id :"))));
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					} catch (ServiceException e) {
						IOUtils.print(e.getMessage());
					}
					break;
				default:
					System.exit(0);
				}
				break;
			case 1:
				switch(classe) {
				case 0:
					try {
						IOUtils.print("number of updated rows : " + clientService.delete(IOUtils.readInt("enter client ID :")));
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					} catch (ServiceException e) {
						IOUtils.print(e.getMessage());
					}
					break;
				case 1:
					try {
						IOUtils.print("number of updated rows : " + vehicleService.delete(IOUtils.readInt("enter vehicle ID :")));
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					}
					break;
				case 2:
					try {
						IOUtils.print("number of updated rows : " + reservationService.delete(IOUtils.readInt("enter reservation ID :")));
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					} catch (ServiceException e) {
						IOUtils.print(e.getMessage());
					}
					break;
				default:
					System.exit(0);
				}
				break;
			case 2:
				switch(classe) {
				case 0: //client
					try {
						Optional<Client> client = clientService.findById(IOUtils.readInt("enter client ID :"));
						if (client.isPresent()) { 
							IOUtils.print(client.get().toString()); 
						} else {
							IOUtils.print("no client has this id");
						}
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					} catch (ServiceException e) {
						IOUtils.print(e.getMessage());
					}
					break;
				case 1: //vehicle
					try {
						Optional<Vehicle> vehicle = vehicleService.findById(IOUtils.readInt("enter vehicle ID :"));
						if (vehicle.isPresent()) { 
							IOUtils.print(vehicle.get().toString());
						} else {
							IOUtils.print("no vehicle has this id");
						}
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					}
					break;
				case 2:
					IOUtils.print("0 - find by client id");
					IOUtils.print("1 - find by vehicle id");
					switch(IOUtils.readInt("Choisir une classe :")) {
					case 0:
						try {
							IOUtils.print("list of reservation by client Id :\n" + reservationService.findResaByClientId(IOUtils.readInt("enter client ID :")));
						} catch (DaoException e) {
							IOUtils.print("error in SQL search");
						} catch (ServiceException e) {
							IOUtils.print(e.getMessage());
						}
						break;
					case 1:
						try {
							IOUtils.print("list of reservation by vehicle Id :\n" + reservationService.findResaByVehicleId(IOUtils.readInt("enter vehicle ID :")));
						} catch (DaoException e) {
							IOUtils.print("error in SQL search");
						} catch (ServiceException e) {
							IOUtils.print(e.getMessage());
						}
					}
					break;
				default:
					System.exit(0);
				}
				break;
			case 3:
				switch(classe) {
				case 0: //client
					try {
						IOUtils.print("list of clients :\n" + clientService.findAll());
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					} catch (ServiceException e) {
						IOUtils.print(e.getMessage());
					}
					break;
				case 1: //vehicle
					try {
						IOUtils.print("list of vehicles :\n" + vehicleService.findAll());
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					} catch (ServiceException e) {
						IOUtils.print(e.getMessage());
					}
					break;
				case 2:
					try {
						IOUtils.print("list of reservation :\n" + reservationService.findAll());
					} catch (DaoException e) {
						IOUtils.print("error in SQL search");
					} catch (ServiceException e) {
						IOUtils.print(e.getMessage());
					}
				default:
					System.exit(0);
				}
			}
		}
	}
}
