package com.epf.rentmanager.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import org.springframework.stereotype.Service;

import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;

@Service
public class ClientService {

	private ClientDao clientDao;
//	private ReservationService reservationService;
//	public static ClientService instance;
	
//	private ClientService(ClientDao clientdao, ReservationService reservationService) {
//		this.clientDao = clientdao;
//		this.reservationService = reservationService;
//	}
	
	public ClientService(ClientDao clientDao) {
		this.clientDao = clientDao;
	}

	public long create(Client client) throws ServiceException, DaoException {
		if (client.getNom().length() < 3) {
			throw new ServiceException("last name too short : need at least 3 characters");
		} else {
			client.setNom(client.getNom().toUpperCase());
		}
		if (client.getPrenom().length() < 3) {
			throw new ServiceException("first name too short : need at least 3 characters");
		}
		if (!client.getEmail().contains("@") || !client.getEmail().substring(client.getEmail().indexOf("@")).contains(".") || client.getEmail().length()<=5) {
			throw new ServiceException("incorrect email adress");
		}
		for(Client clients : clientDao.findAll()) {
			if (clients.getEmail().equalsIgnoreCase(client.getEmail())) {
				throw new ServiceException("email adress already used");
			}
		}
		if (ChronoUnit.YEARS.between(client.getNaissance(), LocalDate.now()) < 18) {
			throw new ServiceException("you need to be of major age");
		}
		
		return clientDao.create(client);
	}
	
	public long count() throws ServiceException, DaoException {
		return clientDao.count();
	}
	
	public long update(Client client) throws ServiceException, DaoException {
		if (client.getNom().length() < 3) {
			throw new ServiceException("last name too short : need at least 3 characters");
		} else {
			client.setNom(client.getNom().toUpperCase());
		}
		if (client.getPrenom().length() < 3) {
			throw new ServiceException("first name too short : need at least 3 characters");
		}
		if (!client.getEmail().contains("@") || !client.getEmail().substring(client.getEmail().indexOf("@")).contains(".") || client.getEmail().length()<=5) {
			throw new ServiceException("incorrect email adress");
		}
		for(Client clients : clientDao.findAll()) {
			if (clients.getId()!= client.getId() && clients.getEmail().equalsIgnoreCase(client.getEmail())) {
				throw new ServiceException("email adress already used");
			}
		}
		if (ChronoUnit.YEARS.between(client.getNaissance(), LocalDate.now()) < 18) {
			throw new ServiceException("you need to be of major age");
		}
		
		return clientDao.update(client);
	}

	public int delete(long id) throws ServiceException, DaoException {
		int deletedentries = clientDao.delete(id);
		return deletedentries;
	}
	
	public Optional<Client> findById(long id) throws ServiceException, DaoException {
		return clientDao.findById(id);
	}

	public List<Client> findAll() throws ServiceException, DaoException {
		return clientDao.findAll();
	}
	
}
