package com.epf.rentmanager.model;



public class Vehicle {
	private String constructeur, modele;
	private short nb_places;
	private long id;
	
	public Vehicle(String constructeur, String modele, short nb_places, long id) {
		super();
		this.constructeur = constructeur;
		this.modele = modele;
		this.nb_places = nb_places;
		this.id = id;
	}
		

	public Vehicle(String constructeur, String modele, short nb_places) {
		super();
		this.constructeur = constructeur;
		this.modele = modele;
		this.nb_places = nb_places;
		this.id = -1;
	}
	

	@Override
	public String toString() {
		return "Vehicle [constructeur=" + constructeur + ", modele=" + modele + ", nb_places=" + nb_places + ", id="
				+ id + "]";
	}

	public String getConstructeur() {
		return constructeur;
	}

	public void setConstructeur(String constructeur) {
		this.constructeur = constructeur;
	}

	public String getModele() {
		return modele;
	}

	public void setModele(String modele) {
		this.modele = modele;
	}

	public short getNb_places() {
		return nb_places;
	}

	public void setNb_places(short nb_places) {
		this.nb_places = nb_places;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
	
	
}
