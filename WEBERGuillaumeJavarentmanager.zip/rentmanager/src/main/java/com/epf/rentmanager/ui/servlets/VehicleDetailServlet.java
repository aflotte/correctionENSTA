package com.epf.rentmanager.ui.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.service.VehicleService;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.service.VehicleService;

@WebServlet("/cars/details")
public class VehicleDetailServlet extends HttpServlet {

	@Autowired
	ClientService clientService;
	@Autowired
	VehicleService vehicleService;
	@Autowired
	ReservationService reservationService;
	@Override
	public void init() throws ServletException {
		super.init();
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/vehicles/details.jsp");
		try {
			Optional<Vehicle> vehicle = vehicleService.findById(Long.parseLong(request.getParameter("id")));
			if (vehicle.isPresent()) {
				request.setAttribute("vehicle", vehicle.get());
			}
			List<Reservation> allReservations = reservationService.findAll();
			List<Reservation> reservations = reservationService.findAll();
			List<Client> allClients = clientService.findAll();
			List<Client> clients = new ArrayList<Client>();
			int nbReservation = allReservations.size();
			for (int i=nbReservation-1; i > -1;i--) {
				if (allReservations.get(i).getVehicle_id()==vehicle.get().getId()) {
					boolean clientInList = false;
					for (Client client : clients) {
						if(client.getId()==allReservations.get(i).getClient_id()) {
							clientInList=true;
							break;
						}
					}
					if (!clientInList) {
						for (Client client : allClients) {
							if(client.getId()==allReservations.get(i).getClient_id()) {
								clients.add(client);
								break;
							}
						}
					}
				} else {
					reservations.remove(i);
				}
			}
			request.setAttribute("reservations", reservations);
			request.setAttribute("clients", clients);
			request.setAttribute("nbClient", clients.size());
			request.setAttribute("nbReservation", reservations.size());
		} catch (final Exception e) {
			dispatcher.forward(request, response);
		}
		
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
