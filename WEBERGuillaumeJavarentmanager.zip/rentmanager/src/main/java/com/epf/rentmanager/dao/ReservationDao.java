package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.persistence.ConnectionManager;

@Repository
public class ReservationDao {

	private static ReservationDao instance = null;
	private ReservationDao() {}
	public static ReservationDao getInstance() {
		if(instance == null) {
			instance = new ReservationDao();
		}
		return instance;
	}
	
	private static final String CREATE_RESERVATION_QUERY = "INSERT INTO Reservation(client_id, vehicle_id, debut, fin) VALUES(?, ?, ?, ?);";
	private static final String UPDATE_RESERVATION_QUERY = "UPDATE Reservation SET client_id=?, vehicle_id=?, debut=?, fin=? WHERE id=?;";
	private static final String DELETE_RESERVATION_QUERY = "DELETE FROM Reservation WHERE id=?;";
	private static final String FIND_RESERVATION_QUERY = "SELECT vehicle_id, client_id, debut, fin FROM Reservation WHERE id=?;";
	private static final String FIND_RESERVATIONS_BY_CLIENT_QUERY = "SELECT id, vehicle_id, debut, fin FROM Reservation WHERE client_id=?;";
	private static final String FIND_RESERVATIONS_BY_VEHICLE_QUERY = "SELECT id, client_id, debut, fin FROM Reservation WHERE vehicle_id=?;";
	private static final String FIND_RESERVATIONS_QUERY = "SELECT id, client_id, vehicle_id, debut, fin FROM Reservation;";
	private static final String COUNT_RESERVATIONS = "SELECT COUNT(*) FROM Reservation;";
	
		
	public long create(Reservation reservation) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(CREATE_RESERVATION_QUERY, Statement.RETURN_GENERATED_KEYS);
		) {	
			stmt.setLong(1, reservation.getClient_id());
			stmt.setLong(2, reservation.getVehicle_id());
			stmt.setDate(3, Date.valueOf(reservation.getDebut()));
			stmt.setDate(4, Date.valueOf(reservation.getFin()));
			
			stmt.executeUpdate();
			ResultSet resultSet = stmt.getGeneratedKeys();
			if (resultSet.next()) {
				if (reservation.getId() == -1) {
					reservation.setId(resultSet.getLong(1));
				}
				return resultSet.getInt(1);
			} else {
				throw new DaoException();
			}
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	public int delete(Reservation reservation) throws DaoException {
		return this.delete(reservation.getId());
	}
	
	public int delete(long id) throws DaoException {
		try (
				Connection connection = ConnectionManager.getConnection();
				PreparedStatement stmt = connection.prepareStatement(DELETE_RESERVATION_QUERY);
			) {	
				stmt.setLong(1, id);
				
				return stmt.executeUpdate();
				
			} catch(SQLException e) {
				throw new DaoException();
			}
	}
	
	public long count() throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(COUNT_RESERVATIONS);
		) {	
			ResultSet resultSet = stmt.executeQuery();
			
			if (resultSet.next()) {
				return resultSet.getLong(1);
			} else {
				throw new DaoException();
			}
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	public long update(Reservation reservation) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(UPDATE_RESERVATION_QUERY, Statement.RETURN_GENERATED_KEYS);
		) {	
			stmt.setLong(1, reservation.getClient_id());
			stmt.setLong(2, reservation.getVehicle_id());
			stmt.setDate(3, Date.valueOf(reservation.getDebut()));
			stmt.setDate(4, Date.valueOf(reservation.getFin()));
			stmt.setLong(5, reservation.getId());
			
			stmt.executeUpdate();
			ResultSet resultSet = stmt.getGeneratedKeys();
			if (resultSet.next()) {
				if (reservation.getId() == -1) {
					reservation.setId(resultSet.getLong(1));
				}
				return resultSet.getInt(1);
			} else {
				throw new DaoException();
			}
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	public List<Reservation> findResaByClientId(long clientId) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(FIND_RESERVATIONS_BY_CLIENT_QUERY);
		) {	
			stmt.setLong(1, clientId);
			
			ResultSet resultSet = stmt.executeQuery();
			
			List<Reservation> reservations = new ArrayList<Reservation>();
			while (resultSet.next()) {
				reservations.add(new Reservation(resultSet.getDate(3).toLocalDate(), resultSet.getDate(4).toLocalDate(), resultSet.getLong(1), clientId, resultSet.getLong(2)));
			}
			return reservations;
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	public List<Reservation> findResaByVehicleId(long vehicleId) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(FIND_RESERVATIONS_BY_VEHICLE_QUERY);
		) {	
			stmt.setLong(1, vehicleId);
			
			ResultSet resultSet = stmt.executeQuery();
			
			List<Reservation> reservations = new ArrayList<Reservation>();
			while (resultSet.next()) {
				reservations.add(new Reservation(resultSet.getDate(3).toLocalDate(), resultSet.getDate(4).toLocalDate(), resultSet.getLong(1), resultSet.getLong(2), vehicleId));
			}
			return reservations;
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
	
	public Optional<Reservation> findById(long id) throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(FIND_RESERVATION_QUERY);
		) {	
			stmt.setLong(1, id);
			
			ResultSet resultSet = stmt.executeQuery();
			
//			List<Reservation> reservations = new ArrayList<Reservation>();
//			while (resultSet.next()) {
//				reservations.add(new Reservation(resultSet.getDate(3).toLocalDate(), resultSet.getDate(4).toLocalDate(), resultSet.getLong(1), resultSet.getLong(2), id));
//			}
//			return reservations;
			if (resultSet.next()) {
				Reservation reservation = new Reservation(resultSet.getDate(3).toLocalDate(), resultSet.getDate(4).toLocalDate(), id, resultSet.getLong(2), resultSet.getLong(1));
				return Optional.of(reservation);
			} else {
				throw new DaoException();
			}
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}

	public List<Reservation> findAll() throws DaoException {
		try (
			Connection connection = ConnectionManager.getConnection();
			PreparedStatement stmt = connection.prepareStatement(FIND_RESERVATIONS_QUERY);
		) {	
			
			ResultSet resultSet = stmt.executeQuery();
			
			List<Reservation> reservations = new ArrayList<Reservation>();
			while (resultSet.next()) {
				reservations.add(new Reservation(resultSet.getDate(4).toLocalDate(), resultSet.getDate(5).toLocalDate(), resultSet.getLong(1), resultSet.getLong(2), resultSet.getLong(3)));
			}
			return reservations;
			
		} catch(SQLException e) {
			throw new DaoException();
		}
	}
}
