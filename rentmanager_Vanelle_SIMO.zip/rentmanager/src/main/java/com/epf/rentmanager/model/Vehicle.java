package com.epf.rentmanager.model;

import java.time.LocalDate;

public class Vehicle {

	// attributs

	private long id;
	private String constructeur;
	private String modele;
	private int nb_places;
	
	// getters and setters
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getConstructeur() {
		return constructeur;
	}
	public void setConstructeur(String constructeur) {
		this.constructeur = constructeur;
	}
	public String getModele() {
		return modele;
	}
	public void setModele(String modele) {
		this.modele = modele;
	}
	public int getNb_places() {
		return nb_places;
	}
	public void setNb_places(int nb_places) {
		this.nb_places = nb_places;
	}

	
	// constructeurs
	
	public Vehicle(long id, String constructeur, String modele, int nb_places) {
		super();
		this.id = id;
		this.constructeur = constructeur;
		this.modele = modele;
		this.nb_places = nb_places;
	}
	
	public Vehicle() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		return "Vehicule [id=" + id + ", constructeur=" + constructeur + ", modele=" + modele + ", nb_places="
				+ nb_places + "]";
	}
	
	

}
