package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.persistence.ConnectionManager;
import org.springframework.stereotype.Repository;

@Repository
public class VehicleDao {
	
	private static final String CREATE_VEHICLE_QUERY = "INSERT INTO Vehicle(constructeur, modele, nb_places) VALUES(?, ?, ?);";
	private static final String DELETE_VEHICLE_QUERY = "DELETE FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICLE_QUERY = "SELECT id, constructeur, modele, nb_places FROM Vehicle WHERE id=?;";
	private static final String FIND_VEHICLES_QUERY = "SELECT id, constructeur,modele, nb_places FROM Vehicle;";
	private static final String COUNT_VEHICLE_QUERY = "SELECT COUNT(*) as count FROM Vehicle;";
	private static final String COUNT_CLIENTS_OF_VEHICLE_QUERY = "SELECT COUNT (DISTINCT client_id) as count FROM Vehicle JOIN Reservation on Vehicle.id= Reservation.vehicle_id where vehicle.id = ?;";	
	private static final String UPDATE_VEHICLE_QUERY = "UPDATE Vehicle SET constructeur = ?, modele =?, nb_places= ? WHERE Vehicle.id = ?;";


	/**
	 * Crée et ajoute une nouvelle voiture à la base de données
	 * @return l'id de la voiture créée
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params voiture : un objet de type voiture
	 */
	public long create(Vehicle vehicle) throws DaoException {
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(CREATE_VEHICLE_QUERY,Statement.RETURN_GENERATED_KEYS)
		   ) {
			
			stmt.setString(1, vehicle.getConstructeur());
			stmt.setString(2, vehicle.getModele());
			stmt.setInt(3, vehicle.getNb_places());

			
			stmt.executeUpdate();
			
			ResultSet resultSet = stmt.getGeneratedKeys();
			
			int id = 0;
			
			if(resultSet.next()) {
				id = resultSet.getInt(1);
			}
			
			resultSet.close();
			return id;
			
		} catch (SQLException throwable) {
			throw new DaoException(throwable.getMessage());
		}
		
		
	}

	/**
	 * Met à jour une voiture de la base de données
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params voiture : un objet de type voiture
	 */
	public long update(Vehicle vehicle) throws DaoException {
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(UPDATE_VEHICLE_QUERY)
		   ) {
			
			stmt.setString(1, vehicle.getConstructeur());
			stmt.setString(2, vehicle.getModele());
			stmt.setInt(3, vehicle.getNb_places());
			stmt.setInt(4, (int) vehicle.getId());

			
			stmt.executeUpdate();
			
		
			return 0;
			
		} catch (SQLException throwable) {
			throw new DaoException(throwable.getMessage());
		}
		
		
	}

	/**
	 * Compte le nombre de voitures de la base de données
	 * @return le nombre de voitures
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 *
	 */
	public int count() throws DaoException{
		
		int nb_voitures = 0;
		try (
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(COUNT_VEHICLE_QUERY)
			){
			
			ResultSet resultset = stmt.executeQuery();
			if (resultset.next()) {
				nb_voitures = resultset.getInt("count");			
				
			}
		}catch (SQLException e) {
			
			throw new DaoException("Décompte impossible",e);
		}
		return nb_voitures;
	}

	/**
	 * Compte le nombre de clients associés à la voiture
	 * @return le nombre de clients
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params voitureId type int
	 */
	public int countClients(int vehicle_id) throws DaoException{

		int nb_clients = 0;
		try (
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(COUNT_CLIENTS_OF_VEHICLE_QUERY)
			){
			
			stmt.setInt(1, vehicle_id);
			ResultSet resultset = stmt.executeQuery();
			
			if (resultset.next()) {
				nb_clients = resultset.getInt("count");			
				
			}
		}catch (SQLException e) {
			
			throw new DaoException("Décompte impossible",e);
		}
		return nb_clients;
	}

	/**
	 * Supprime une voiture voiture
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params voiture: un objet de type voiture
	 */
	public int delete(Vehicle vehicle) throws DaoException {
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(DELETE_VEHICLE_QUERY)
		   ) {
			
			stmt.setLong(1, vehicle.getId());
			stmt.executeUpdate();
			
			return 0;
		} catch (SQLException throwable) {
			throw new DaoException(throwable.getMessage());
			
	}
		
	}

	/**
	 * Recherche la voiture associée à un id voiture
	 * @return  voiture
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params voitureId type long
	 */
	public Optional<Vehicle> findById(long id) throws DaoException {
		
		
		Optional<Vehicle> result = Optional.empty();
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(FIND_VEHICLE_QUERY)
		   ) {
				stmt.setLong(1, id);
				
				ResultSet resultSet = stmt.executeQuery();
				
				
				while (resultSet.next()) {
		
					Vehicle vehicle = new Vehicle();
					vehicle.setId(id);
					vehicle.setConstructeur(resultSet.getString("constructeur"));
					vehicle.setModele(resultSet.getString("modele"));
					vehicle.setNb_places(resultSet.getInt("nb_places"));

					
					result = Optional.of(vehicle);
				}
				
				resultSet.close();
				stmt.close();
				conn.close();
				
	} catch (SQLException e) {
		throw new DaoException("Vehicle not found : invalid Id",e);
	}
		
		return result;
	}

	/**
	 * Liste toutes les voitures de la base de données
	 * @return liste de voitures
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 *
	 */

	public List<Vehicle> findAll() throws DaoException {
		
		List<Vehicle> result = new ArrayList <Vehicle>();
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(FIND_VEHICLES_QUERY)
		   ) {
				
				ResultSet resultSet = stmt.executeQuery();
				
				
				while (resultSet.next()) {
		
					Vehicle vehicle = new Vehicle();
					vehicle.setId(resultSet.getInt("id"));
					vehicle.setConstructeur(resultSet.getString("constructeur"));
					vehicle.setModele(resultSet.getString("modele"));
					vehicle.setNb_places(resultSet.getInt("nb_places"));

					
					result.add(vehicle);
				}
				
				resultSet.close();
				stmt.close();
				conn.close();
				
	} catch (SQLException e) {
		throw new DaoException("Empty", e);
	}
		
		return result;
		
	}

		
	}
	
