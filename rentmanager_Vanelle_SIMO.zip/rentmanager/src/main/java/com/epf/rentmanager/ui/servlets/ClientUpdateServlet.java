package com.epf.rentmanager.ui.servlets;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

@WebServlet("/users/update")
public class ClientUpdateServlet extends HttpServlet{

	@Autowired
	private ClientService clientService;

	@Override
	public void init()throws ServletException{
		super.init();
		SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
	}

	protected void doGet (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/views/users/update.jsp");
		
		int id = Integer.parseInt(request.getParameter("id"));
		
		try {
			request.setAttribute("client", clientService.findById(id));
		} catch (DaoException e1) {
			
			e1.printStackTrace();
		} catch (ServiceException e) {
			
			e.printStackTrace();
		}
		
		
		dispatcher.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		Client newClient = new Client();
		
		newClient.setId(Integer.parseInt(request.getParameter("id")));
		newClient.setNom(request.getParameter("last_name"));
		newClient.setPrenom(request.getParameter("first_name"));
		newClient.setEmail(request.getParameter("email"));
		newClient.setNaissance(LocalDate.parse(request.getParameter("naissance"), format));
		
		
		try {
			
			clientService.update(newClient);
			response.sendRedirect(request.getContextPath()+"/users");
			
		} catch (DaoException e) {
			
			e.printStackTrace();
			System.out.println("Erreur lors de la mise à jour");
			doGet(request, response);
		}catch (ServiceException e1){
			e1.printStackTrace();
			System.out.println("Erreur lors de la mise à jour");
		}
		
	}

}
