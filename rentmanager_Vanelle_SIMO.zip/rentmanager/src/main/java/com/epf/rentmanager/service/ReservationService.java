package com.epf.rentmanager.service;


import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.dao.ReservationDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ReservationService {

	private ReservationDao reservationDao;

	@Autowired
	private ReservationService(ReservationDao reservationDao) {
		this.reservationDao = reservationDao;
	}


	/**
	 * Crée et ajoute une nouvelle réservation à la base de données
	 * @return l'id de la réservation créée
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 * @params reservation : un objet de type reservation
	 */
	public long create(Reservation reservation) throws ServiceException, DaoException {

		reservationValidation(reservation);
		return reservationDao.create(reservation);
		
	}

	/**
	 * Met à jour une réservation de la base de données
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 * @params reservation : un objet de type reservation
	 */
	public long update(Reservation reservation) throws ServiceException, DaoException {

		reservationValidation(reservation);
		return reservationDao.update(reservation);
		
	}

	/**
	 *
	 * @return le nombre de réservations de la base de données
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 *
	 */
	public int count() throws DaoException {
		
		return ReservationDao.count();
	}


	/**
	 * Liste les reservations associées à un client
	 * @return liste de reservations
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params clientId type long
	 */
	public List<Reservation> findResaByClientId(long clientid) throws  DaoException {
		
		return reservationDao.findResaByClientId(clientid);
		
	}

	/**
	 * Liste les reservations associées à un vehicule
	 * @return liste de reservations
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params vehiculeId type long
	 */
	public List<Reservation> findResaByVehicleId(long vehicleid) throws  DaoException {
		
		return reservationDao.findResaByVehicleId(vehicleid);
		
	}


	/**
	 * Recherche la reservation associée à un id reservation
	 * @return  reservation
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 * @params reservationId type long
	 */
	public Reservation findById(long id) throws ServiceException, DaoException {
		
		
		Optional<Reservation> rentOptional = ReservationDao.findById(id);
		
		if (rentOptional.isPresent()) {
			return rentOptional.get();
		}
		
		throw new ServiceException("Rent not found : incorrect Id");
	}


	/**
	 * Liste toutes les reservations de la base de données
	 * @return liste de reservations
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 *
	 */
	public List<Reservation> findAll() throws ServiceException, DaoException {
		
		return reservationDao.findAll();
		
	}

	/**
	 * supprime une réservation de la base de données
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params reservation : un objet de type reservation
	 */
	public int delete(Reservation reservation) throws DaoException {
		
		return reservationDao.delete(reservation);
	}


	/**
	 *
	 * Valide les données reservation lors de la création et de la mise à jour
	 * @throws ServiceException en cas d'erreur
	 * @param reservation : un objet de type client
	 */
	private void reservationValidation(Reservation reservation) throws ServiceException {
		
		if (reservation.getClient_id() == 0 || reservation.getVehicle_id() == 0) throw new ServiceException("Invalid reservation : something missed");
		if (reservation.getFin().isBefore(reservation.getDebut())) throw new ServiceException("Invalid reservation: fulfill reservation time");
		
	}


	
}
