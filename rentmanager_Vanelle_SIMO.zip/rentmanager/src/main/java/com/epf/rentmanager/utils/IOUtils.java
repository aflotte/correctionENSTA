package com.epf.rentmanager.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IOUtils {
	
	/**
	 * Affiche un message sur la sortie standard
	 * @param message
	 */
	public static void print(String message) {
		System.out.println(message); 
	}
	
	/**
	 * Lit un texte et affiche un message sur la sortie standard
	 * @param message
	 * @param mandatory
	 */
	public static String readString(String message, boolean mandatory) {
		print(message);
		
		String input = null;
		int attempt = 0;
		
		do {
			if (attempt >= 1) {
				print("Cette valeur est obligatoire");
			}
			
			input = readString();
			attempt++;
		} while (mandatory && (input.isEmpty() || input == null));
		
		return input;
	}

	
	/**
	 * Lit un email et affiche un message sur la sortie standard
	 * @param message
	 * @param mandatory
	 */
	
	
	public static String readEmail(String message, boolean mandatory) {
		print(message);
		
		String email = null;
		int done = 0;
		
		do{
			
			int attempt = 0;
			
			
			do {
				if (attempt >= 1) {
					print("Cette valeur est obligatoire");
				}
				
				email = readString();
				attempt++;
			} while (mandatory && (email.isEmpty() || email == null));
			
			
			Pattern p = Pattern
					.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{​​​​2,4}​​​​$");
			Matcher m = p.matcher(email.toUpperCase());

			if(m.matches()) {
					
				done ++;
				
			}
			else {
				print("Insérer un e-mail valide");
			}

		} while(done < 1);
		
		return email;
	}
	
	/*public static String readEmail(String message, boolean mandatory) {
		print(message);
		int compteur = 0;
		String email = null;
		do {

		int attempt = 0;
		do {

		 if (attempt >= 1) {
		print("Cette valeur est obligatoire");
		}
		email = readString();
		attempt++;
		} while (mandatory && (email.isEmpty() || email == null));
		Pattern p = Pattern
		.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}$");
		Matcher m = p.matcher(email.toUpperCase());
		if(m.matches()) {
		compteur++;
		}
		else{
		print("Veuillez saisir un email correct");
		}
		}while(compteur < 1);
		return email;
	}*/
	
	
	/**
	 * Lit un message sur l'entrée standard
	 */
	public static String readString() {
		Scanner scanner = new Scanner(System.in);
		String value = scanner.nextLine();

		return value;
	}
	
	/**
	 * Lit un entier sur l'entrée standard
	 * @param message
	 * @return
	 */
	public static int readInt(String message) {
		print(message);
		
		String input = null;
		int output = 0;
		boolean error = false;
		
		do {
			input = readString();
			error = false;
			
			try {
				output = Integer.parseInt(input);
			} catch (NumberFormatException e) {
				error = true;
				print("Veuillez saisir un nombre");
			}
		} while (error);
		
		return output;
	}
	
	/**
	 * Lit une date sur l'entrée standard
	 * @param message
	 * @param mandatory
	 * @return
	 */
	public static LocalDate readDate(String message, boolean mandatory) {
		print(message);
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        
		LocalDate output = null;
		boolean error = false;
		
		do {
			try {
				error = false;
				String stringDate = readString();
	        	output = LocalDate.parse(stringDate, formatter);
	        } catch (DateTimeParseException e) {
	        	error = true;
	        	print("Veuillez saisir une date valide (dd/MM/yyyy)");
	        } 
		} while (error && mandatory);
        
		return output;
	}
}
