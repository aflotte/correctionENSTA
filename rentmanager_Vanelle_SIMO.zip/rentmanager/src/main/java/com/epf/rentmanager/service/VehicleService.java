package com.epf.rentmanager.service;

import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.dao.ReservationDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.dao.VehicleDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class VehicleService {

	private VehicleDao vehicleDao;

	@Autowired
	private VehicleService(VehicleDao vehicleDao) {
		this.vehicleDao = vehicleDao;
	}


	/**
	 * Crée et ajoute une nouvelle voiture à la base de données
	 * @return l'id de la voiture créée
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params voiture : un objet de type voiture
	 */
	public long create(Vehicle vehicle) throws ServiceException, DaoException {

		vehicleValidation(vehicle);
		return vehicleDao.create(vehicle);
		
	}


	/**
	 * Met à jour une voiture de la base de données
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 * @params voiture : un objet de type voiture
	 */
	public long update(Vehicle vehicle) throws ServiceException, DaoException {

		vehicleValidation(vehicle);
		return vehicleDao.update(vehicle);
		
	}

	/**
	 * Compte le nombre de voitures de la base de données
	 * @return le nombre de voitures
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 *
	 */
	public int count ()  throws ServiceException, DaoException {
		
		return vehicleDao.count();
	}


	/**
	 * Compte le nombre de clients associés à la voiture
	 * @return le nombre de clients
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params voitureId type int
	 */
	public int countClients(int vehicle_id) throws DaoException {
		
		return vehicleDao.countClients(vehicle_id);
	}


	/**
	 * Recherche la voiture associée à un id voiture
	 * @return  voiture
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 * @params voitureId type long
	 */
	public Vehicle findById(long id) throws ServiceException, DaoException {
		
		Optional<Vehicle> vehicleOptional = vehicleDao.findById(id);
		
		if (vehicleOptional.isPresent()) {
			return vehicleOptional.get();
		}
		
		throw new ServiceException("Vehicle not found : incorrect Id");
		
	}

	/**
	 * Liste toutes les voitures de la base de données
	 * @return liste de voitures
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 *
	 */
	public List<Vehicle> findAll() throws DaoException{
			
		return vehicleDao.findAll();
	}


	/**
	 * Supprime une voiture voiture
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params voiture: un objet de type voiture
	 */
	public int delete(Vehicle vehicle) throws DaoException {
		
		return vehicleDao.delete(vehicle);
	}


	/**
	 *
	 * Valide les données vehicule (constructeur et nombre de places) lors de la création et de la mise à jour
	 * @throws ServiceException en cas d'erreur
	 * @param vehicle: un objet de type client
	 */
	private void vehicleValidation(Vehicle vehicle) throws ServiceException {
	
		if (vehicle.getConstructeur() == null || vehicle.getNb_places() <= 1 ) throw new ServiceException("Invalid vehicle : something missed");
	}
		
}
	
