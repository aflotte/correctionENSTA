package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.persistence.ConnectionManager;
import org.springframework.stereotype.Repository;

@Repository
public class ReservationDao {
	
	private static final String CREATE_RESERVATION_QUERY = "INSERT INTO Reservation(client_id, vehicle_id, debut, fin) VALUES(?, ?, ?, ?);";
	private static final String DELETE_RESERVATION_QUERY = "DELETE FROM Reservation WHERE id=?;";
	private static final String FIND_RESERVATIONS_BY_CLIENT_QUERY = "SELECT id, vehicle_id, debut, fin FROM Reservation WHERE client_id=?;";
	private static final String FIND_RESERVATIONS_BY_VEHICLE_QUERY = "SELECT id, client_id, debut, fin FROM Reservation WHERE vehicle_id=?;";
	private static final String FIND_RESERVATIONS_QUERY = "SELECT id, client_id, vehicle_id, debut, fin FROM Reservation;";
	private static final String FIND_RESERVATION_QUERY = "SELECT client_id, vehicle_id, debut, fin FROM Reservation WHERE id=?;";
	private static final String COUNT_RESERVATIONS_QUERY = "SELECT COUNT(*) as count FROM Reservation;";
	private static final String UPDATE_RESERVATION_QUERY = "UPDATE Reservation SET client_id = ?, vehicle_id =?, debut= ?, fin = ? WHERE Reservation.id = ?;";


	/**
	 * Crée et ajoute une nouvelle réservation à la base de données
	 * @return l'id de la réservation créée
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params reservation : un objet de type reservation
	 */
	public long create(Reservation reservation) throws DaoException {
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(CREATE_RESERVATION_QUERY,Statement.RETURN_GENERATED_KEYS)
		   ) {
			
			stmt.setInt(1, reservation.getClient_id());
			stmt.setInt(2, reservation.getVehicle_id());
			stmt.setDate(3, Date.valueOf(reservation.getDebut()));
			stmt.setDate(4, Date.valueOf(reservation.getFin()));
			
			stmt.executeUpdate();
			
			ResultSet resultSet = stmt.getGeneratedKeys();
			
			int id = 0;
			
			if(resultSet.next()) {
				id = resultSet.getInt(1);
			}
			
			resultSet.close();
			return id;
			
		} catch (SQLException throwable) {
			throw new DaoException(throwable.getMessage());
		}
		
	}

	/**
	 * Met à jour une réservation de la base de données
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params reservation : un objet de type reservation
	 */
	public long update(Reservation reservation) throws DaoException {
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(UPDATE_RESERVATION_QUERY)
		   ) {
			
			stmt.setLong(1, reservation.getClient_id());
			stmt.setLong(2, reservation.getVehicle_id());
			stmt.setDate(3, Date.valueOf(reservation.getDebut()));
			stmt.setDate(4, Date.valueOf(reservation.getFin()));
			stmt.setInt(5, (int) reservation.getId());

			
			stmt.executeUpdate();
			
		
			return 0;
			
		} catch (SQLException throwable) {
			throw new DaoException(throwable.getMessage());
		}
		
		
	}

	/**
	 *
	 * @return le nombre de réservations de la base de données
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 *
	 */
	public static int count() throws DaoException{
			
			int nb_reservations = 0;
			try (
					Connection conn = ConnectionManager.getConnection();
					PreparedStatement stmt = conn.prepareStatement(COUNT_RESERVATIONS_QUERY)
				){
				
				ResultSet resultset = stmt.executeQuery();
				if (resultset.next()) {
					nb_reservations = resultset.getInt("count");			
					
				}
			}catch (SQLException e) {
				
				throw new DaoException("Décompte impossible",e);
			}
			return nb_reservations;
		}

	/**
	 * supprime une réservation de la base de données
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params reservation : un objet de type reservation
	 */
	public int delete(Reservation reservation) throws DaoException {
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(DELETE_RESERVATION_QUERY)
		   ) {
			
			stmt.setLong(1, reservation.getId());
			stmt.executeUpdate();
			
			return 0;
		} catch (SQLException throwable) {
			throw new DaoException(throwable.getMessage());
	}
		
		
	}

	/**
	 * Liste les reservations associées à un client
	 * @return liste de reservations
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params clientId type long
	 */
	public List<Reservation> findResaByClientId(long clientId) throws DaoException {
		
		
		List<Reservation> result = new ArrayList<Reservation>();
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(FIND_RESERVATIONS_BY_CLIENT_QUERY)
		   ) {
				stmt.setLong(1, clientId);
				
				ResultSet resultSet = stmt.executeQuery();
				
				
				while (resultSet.next()) {
		
					Reservation reservation = new Reservation();
					reservation.setId(resultSet.getInt("id"));
					reservation.setVehicle_id(resultSet.getInt("vehicle_id"));
					reservation.setDebut(resultSet.getDate("debut").toLocalDate());
					reservation.setFin(resultSet.getDate("fin").toLocalDate());

					
					result.add(reservation);
				}
				
				resultSet.close();
				stmt.close();
				conn.close();
				
	} catch (SQLException e) {
		throw new DaoException("Aucune réservation pour ce client",e);
	}
		
		return result;
		
	}

	/**
	 * Liste les reservations associées à un vehicule
	 * @return liste de reservations
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params vehiculeId type long
	 */
	
	public List<Reservation> findResaByVehicleId(long vehicleId) throws DaoException {
		
		
		
		List<Reservation> result = new ArrayList<Reservation>();
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(FIND_RESERVATIONS_BY_VEHICLE_QUERY)
		   ) {
				stmt.setLong(1, vehicleId);
				
				ResultSet resultSet = stmt.executeQuery();
				
				
				while (resultSet.next()) {
		
					Reservation reservation = new Reservation();
					reservation.setId(resultSet.getInt("id"));
					reservation.setClient_id(resultSet.getInt("client_id"));
					reservation.setDebut(resultSet.getDate("debut").toLocalDate());
					reservation.setFin(resultSet.getDate("fin").toLocalDate());

					
					result.add(reservation);
				}
				
				resultSet.close();
				stmt.close();
				conn.close();
				
	} catch (SQLException e) {
		throw new DaoException("Ce véhicule n'a aucune réservation",e);
	}
		
		return result;
		 
	}

	/**
	 * Recherche la reservation associée à un id reservation
	 * @return  reservation
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params reservationId type long
	 */
	public static Optional<Reservation> findById(Long id) throws DaoException {
		
		
		
		Optional<Reservation> result = Optional.empty();
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(FIND_RESERVATION_QUERY)
		   ) {
				stmt.setLong(1, id);
				
				ResultSet resultSet = stmt.executeQuery();
				
				
				while (resultSet.next()) {
		
					Reservation reservation = new Reservation();
					reservation.setId(id);
					reservation.setVehicle_id(resultSet.getInt("vehicle_id"));
					reservation.setClient_id(resultSet.getInt("client_id"));
					reservation.setDebut(resultSet.getDate("debut").toLocalDate());
					reservation.setFin(resultSet.getDate("fin").toLocalDate());

					
					result = Optional.of(reservation);
				}
				
				resultSet.close();
				stmt.close();
				conn.close();
				
	} catch (SQLException e) {
		throw new DaoException("Ce véhicule n'a aucune réservation",e);
	}
		
		return result;
		 
	}


	/**
	 * Liste toutes les reservations de la base de données
	 * @return liste de reservations
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 *
	 */
	public List<Reservation> findAll() throws DaoException {
		
		
		List<Reservation> result = new ArrayList <Reservation>();
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(FIND_RESERVATIONS_QUERY)
		   ) {
				
				ResultSet resultSet = stmt.executeQuery();
				
				
				while (resultSet.next()) {
		
					Reservation reservation = new Reservation();
					reservation.setId(resultSet.getInt("id"));
					reservation.setVehicle_id(resultSet.getInt("vehicle_id"));
					reservation.setClient_id(resultSet.getInt("client_id"));
					reservation.setDebut(resultSet.getDate("debut").toLocalDate());
					reservation.setFin(resultSet.getDate("fin").toLocalDate());

					
					result.add(reservation);
				}
				
				resultSet.close();
				stmt.close();
				conn.close();
				
	} catch (SQLException e) {
		throw new DaoException("Empty", e);
	}
		
		return result;
		
	}

		 
}
