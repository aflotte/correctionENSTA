package com.epf.rentmanager.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.persistence.ConnectionManager;

@Repository
public class ClientDao {
	
	private static final String CREATE_CLIENT_QUERY = "INSERT INTO Client(nom, prenom, email, naissance) VALUES(?, ?, ?, ?);";
	private static final String DELETE_CLIENT_QUERY = "DELETE FROM Client WHERE id=?;";
	private static final String FIND_CLIENT_QUERY = "SELECT nom, prenom, email, naissance FROM Client WHERE id=?;";
	private static final String FIND_CLIENTS_QUERY = "SELECT id, nom, prenom, email, naissance FROM Client;";
	private static final String COUNT_CLIENT_QUERY = "SELECT COUNT(*) as count FROM Client;";
	private static final String COUNT_RESERVED_VEHICLES_QUERY = "SELECT COUNT (DISTINCT vehicle_id) as count FROM Client JOIN Reservation on Client.id= Reservation.client_id where client.id = ?;";
	private static final String FIND_RESERVED_VEHICLES_QUERY = "SELECT DISTINCT on (v.id) v.id, v.modele, v.constructeur, v.nb_places FROM Client as c, Reservation as r, Vehicle as v where c.id = ? and v.id=r.vehicle_id and c.id=r.client_id;";
	private static final String UPDATE_CLIENT_QUERY = "UPDATE Client SET nom = ?, prenom =?, email= ?, naissance = ? WHERE Client.id = ?;";


    /**
     * Utilisé pour créer un nouveau client dans la base de données
     * @return l'id du client crée
     * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
     * @params client : un objet de type client
     */
	public long create(Client client) throws DaoException {
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(CREATE_CLIENT_QUERY,Statement.RETURN_GENERATED_KEYS)
		   ) {
			
			stmt.setString(1, client.getNom().toUpperCase());
			stmt.setString(2, client.getPrenom());
			stmt.setString(3, client.getEmail());
			stmt.setDate(4, Date.valueOf(client.getNaissance()));
			
			stmt.executeUpdate();
			
			ResultSet resultSet = stmt.getGeneratedKeys();
			
			int id = 0;
			
			if(resultSet.next()) {
				id = resultSet.getInt(1);
			}
			
			resultSet.close();
			return id;
			
		} catch (SQLException throwable) {
			throw new DaoException(throwable.getMessage());
		}
		
	}

    /**
     * Utilisé pour mettre à jour un ancien client de la base de données
     * @return 0
     * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
     * @params client : un objet de type client
     */
	public long update(Client client) throws DaoException {
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(UPDATE_CLIENT_QUERY)
		   ) {
			
			stmt.setString(1, client.getNom());
			stmt.setString(2, client.getPrenom());
			stmt.setString(3, client.getEmail());
			stmt.setDate(4, Date.valueOf(client.getNaissance()));
			stmt.setInt(5, (int) client.getId());

			
			stmt.executeUpdate();
			
		
			return 0;
			
		} catch (SQLException throwable) {
			throw new DaoException(throwable.getMessage());
		}
		
		
	}

    /**
     * Compte le nombre de clients de la base de données
     * @return le nombre de clients de la base de données
     * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
     *
     */
	
	public int count() throws DaoException{
		
		int nb_clients = 0;
		try (
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(COUNT_CLIENT_QUERY)
			){
			
			ResultSet resultset = stmt.executeQuery();
			if (resultset.next()) {
				nb_clients = resultset.getInt("count");			
				
			}
		}catch (SQLException e) {
			
			throw new DaoException("Décompte impossible",e);
		}
		return nb_clients;
	}

    /**
     * Compte le nombre de véhicules associés à un client
     * @return le nombre de véhicules associés à un client
     * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
     * @params client_id type int
     */
	
	public int countVehicles(int client_id) throws DaoException{
		
		int nb_vehicles = 0;
		try (
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(COUNT_RESERVED_VEHICLES_QUERY)
			){
			
			stmt.setInt(1, client_id);
			ResultSet resultset = stmt.executeQuery();
			
			if (resultset.next()) {
				nb_vehicles = resultset.getInt("count");			
				
			}
		}catch (SQLException e) {
			
			throw new DaoException("Décompte impossible",e);
		}
		return nb_vehicles;
	}

    /**
     * Liste les véhicules associés à un client
     * @return la liste des véhicules associés à un client
     * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
     * @params client_id type int
     */
	public List<Vehicle> findVehicules(int client_id) throws DaoException {
		
		List<Vehicle> result = new ArrayList <Vehicle>();
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(FIND_RESERVED_VEHICLES_QUERY)
		   ) {
				
				stmt.setInt(1, client_id);
				ResultSet resultSet = stmt.executeQuery();
				
				
				while (resultSet.next()) {
		
					Vehicle vehicle = new Vehicle();
					vehicle.setId(resultSet.getInt("id"));
					vehicle.setModele(resultSet.getString("modele"));
					vehicle.setConstructeur(resultSet.getString("constructeur"));
					vehicle.setNb_places(resultSet.getInt("nb_places"));
					
					
					result.add(vehicle);
				}
				
				resultSet.close();
				stmt.close();
				conn.close();
				
	} catch (SQLException e) {
		
		e.getStackTrace();
		throw new DaoException("Empty", e);
	}
		
		return result;
		
	}

    /**
     * Supprime un client
     * @return 0
     * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
     * @params client : un objet de type client
     */
	public int delete(Client client) throws DaoException {
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(DELETE_CLIENT_QUERY)
		   ) {
			
			stmt.setLong(1, client.getId());
			stmt.executeUpdate();
			
			return 0;
		} catch (SQLException throwable) {
			throw new DaoException(throwable.getMessage());
	}
		
	}

    /**
     * Recherche un client étant donné son id
     * @return un client
     * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
     * @params id type long
     */
	public Optional<Client> findById(long id) throws DaoException {
		
		Optional<Client> result = Optional.empty();
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(FIND_CLIENT_QUERY)
		   ) {
				stmt.setLong(1, id);
				
				ResultSet resultSet = stmt.executeQuery();
				
				
				while (resultSet.next()) {
		
					Client client = new Client();
					client.setId(id);
					client.setNom(resultSet.getString("nom"));
					client.setPrenom(resultSet.getString("prenom"));
					client.setEmail(resultSet.getString("Email"));
					client.setNaissance(resultSet.getDate("naissance").toLocalDate());
					
					result = Optional.of(client);
				}
				
				resultSet.close();
				stmt.close();
				conn.close();
				
	} catch (SQLException e) {
		throw new DaoException("Client not found : invalid Id",e);
	}
		
		return result;
		
	}


    /**
     *
     * @return La liste des clients de la base de données
     * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
     *
     */

	public List<Client> findAll() throws DaoException {
		
		List<Client> result = new ArrayList <Client>();
		
		try(
				Connection conn = ConnectionManager.getConnection();
				PreparedStatement stmt = conn.prepareStatement(FIND_CLIENTS_QUERY)
		   ) {
				
				ResultSet resultSet = stmt.executeQuery();
				
				
				while (resultSet.next()) {
		
					Client client = new Client();
					client.setId(resultSet.getInt("id"));
					client.setNom(resultSet.getString("nom"));
					client.setPrenom(resultSet.getString("prenom"));
					client.setEmail(resultSet.getString("Email"));
					client.setNaissance(resultSet.getDate("naissance").toLocalDate());
					
					result.add(client);
				}
				
				resultSet.close();
				stmt.close();
				conn.close();
				
	} catch (SQLException e) {
		throw new DaoException("Empty", e);
	}
		
		return result;
		
	}

}

