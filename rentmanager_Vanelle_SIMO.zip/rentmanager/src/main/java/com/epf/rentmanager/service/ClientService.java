package com.epf.rentmanager.service;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Service;

import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Vehicle;
import Configurations.AppConfiguration;

@Service
public class ClientService {

	private ClientDao clientDao;
	
	@Autowired
	private ClientService(ClientDao clientDao) {
		this.clientDao = clientDao;
	}

	/**
	 * Utilisé pour créer un nouveau client dans la base de données
	 * @return l'id du client crée
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 * @params client : un objet de type client
	 */
	public long create(Client client) throws ServiceException, DaoException {
		
		
		clientValidation(client);
		return clientDao.create(client);
		
	}
	/**
	 * Utilisé pour mettre à jour un ancien client de la base de données
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 * @params client : un objet de type client
	 */
	
	public long update(Client client) throws DaoException, ServiceException {

		clientValidation(client);
		return clientDao.update(client);
	}

	/**
	 * Compte le nombre de clients de la base de données
	 * @return le nombre de clients de la base de données
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 *
	 */
	
	public int count() throws DaoException {
		
		return clientDao.count();
	}

	/**
	 * Compte le nombre de véhicules associés à un client
	 * @return le nombre de véhicules associés à un client
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params client_id type int
	 */

	public int countVehicles(int client_id) throws DaoException {
		
		return clientDao.countVehicles(client_id);
	}

	/**
	 * Liste les véhicules associés à un client
	 * @return la liste des véhicules associés à un client
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params client_id type int
	 */
	public List<Vehicle> findVehicule(int client_id) throws DaoException {
			
			
			return clientDao.findVehicules(client_id);
		}

	/**
	 * Recherche un client étant donné son id
	 * @return un client
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete, ServiceException en cas d'erreur dans la logique
	 * @params id type long
	 */
	public Client findById(long id) throws ServiceException, DaoException {
		
		
		Optional<Client> clientOptional = clientDao.findById(id);
		
		if (clientOptional.isPresent()) {
			return clientOptional.get();
		}
		
		throw new ServiceException("Client not found : incorrect Id");
	}

	/**
	 *
	 * @return La liste des clients de la base de données
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 *
	 */
	public List<Client> findAll() throws DaoException{
		
		
		return clientDao.findAll();
	}

	/**
	 * Supprime un client
	 * @return 0
	 * @throws DaoException en cas d'erreur lors de la connexion donnée ou dans la requete
	 * @params client : un objet de type client
	 */
	public int delete(Client client) throws DaoException {
		
		return clientDao.delete(client);
	}

	/**
	 *
	 * Valide les données client lors de la création et de la mise à jour
	 * @throws ServiceException en cas d'erreur
	 * @param client : un objet de type client
	 */
	private void clientValidation(Client client) throws ServiceException {
		
		if (client.getNom() == null || client.getPrenom() == null ) throw new ServiceException("Invalid client : something missed");
		if (Period.between(client.getNaissance(), LocalDate.now()).getYears() < 18) throw new ServiceException("Invalid client : mismatching age");
		
	}
	

	//ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);
	//ClientService clientService = context.getBean(ClientService.class);

}
