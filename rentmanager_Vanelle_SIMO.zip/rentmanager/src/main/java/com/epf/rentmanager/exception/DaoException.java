package com.epf.rentmanager.exception;

public class DaoException extends Exception {

	public DaoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DaoException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public DaoException(String message, Throwable cause) {
		super(message, cause);
		
		
		System.out.println(message);
	}

	public DaoException(String message) {
		super(message);
		
		System.out.println(message);
	}

	public DaoException(Throwable cause) {
		super(cause);
		
	}


}
