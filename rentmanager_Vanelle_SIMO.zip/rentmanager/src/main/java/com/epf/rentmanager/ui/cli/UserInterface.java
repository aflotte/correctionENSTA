package com.epf.rentmanager.ui.cli;

import java.util.List;

import Configurations.AppConfiguration;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import com.epf.rentmanager.model.Reservation;
import com.epf.rentmanager.model.Vehicle;
import com.epf.rentmanager.service.ClientService;
import com.epf.rentmanager.service.ReservationService;
import com.epf.rentmanager.service.VehicleService;
import com.epf.rentmanager.utils.IOUtils;
import org.h2.engine.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import javax.servlet.ServletException;

public class UserInterface {

	private ClientService clientService;
	private VehicleService vehicleService;
	private ReservationService reservationService;

	public UserInterface(){

		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);
		clientService = context.getBean(ClientService.class);
		vehicleService = context.getBean(VehicleService.class);
		reservationService = context.getBean(ReservationService.class);
	}

	private static int choix;

	public static void main(String[] args) throws ServiceException, DaoException {

		UserInterface userInterface = new UserInterface();

		String decision = null;
		
		do {
			
			
			try {
				
				System.out.println("Bienvenue, veullez selectionner une action:\n");
				System.out.println("1 - Creer un client \n2 - Lister les clients \n3 - Récupérer un client \n4 - Création de véhicules \n5 - Lister les véhicules \n6 - Récupérer un véhicule \n7 - Supprimer un client \n8 - Supprimer un véhicule \n9 - Créer une réservation \n10 - Lister les réservations \n11 - Récupérer les réservations d'un client \n12 - Récupérer les réservations d'un véhicule \n13 - Supprimer une réservation \n14 - Quitter");
				
				choix = IOUtils.readInt("\nVotre choix est : ");
				
				if (choix < 1 || choix > 14) {
					
					System.out.println("Veuillez choisir un entier entre 1 et 7 !");
				}
				
				else {
					
					switch(choix) {
					
					case 1:
						
						System.out.println("\n Creation de client");
						
						Client newClient = new Client();
						newClient.setNom(IOUtils.readString("Entrez le nom du client", true));
						newClient.setPrenom(IOUtils.readString("Entrez le prenom du client", true));
						newClient.setEmail(IOUtils.readEmail("Entrez l'e-mail du client", true));
						newClient.setNaissance(IOUtils.readDate("Entrez la date de naissance au format dd/MM/yyyy", true));
						int id_client = (int) userInterface.clientService.create(newClient);
						System.out.println("\nCreation de client terminee, id = " + id_client);
						
						break;
						
					
					case 2:
						
						System.out.println("\n La liste des clients est:");
						
						List<Client> clients = userInterface.clientService.findAll();
						
						for(Client client : clients ) {
							
							System.out.println(client);
						}
						
						break;
						
						
					case 3:
						
						System.out.println("\n Trouver un client par son Id ");
						
						Client foundClient = new Client();
						
						int clientId = IOUtils.readInt("Entrez l'Id du client à trouver");
						
						foundClient = userInterface.clientService.findById(clientId);
						
						break;
						
						
					case 4:
						
						System.out.println("\n Creation de vehicule");
						
						Vehicle newVehicle = new Vehicle();
						newVehicle.setConstructeur(IOUtils.readString("Entrez le nom du constructeur", true));
						newVehicle.setModele(IOUtils.readString("Entrez le modele de la voiture",false));
						newVehicle.setNb_places(IOUtils.readInt("Entrez le nombre de places"));
						int id_vehicle = (int) userInterface.vehicleService.create(newVehicle);
						System.out.println("\nCreation de vehicule terminee, id = " + id_vehicle);
						break;
					
					case 5:
					
						
						System.out.println("\n La liste des vehicules est:");
						
						List<Vehicle> vehicles = userInterface.vehicleService.findAll();
						
						for(Vehicle vehicle : vehicles ) {
							
							System.out.println(vehicle);
						}
						
						break;
						
					
					case 6:
						
						System.out.println("\n Trouver un vehicule par son Id ");
						
						Vehicle foundVehicle = new Vehicle();
						
						int vehicleId = IOUtils.readInt("Entrez l'Id du vehicule à trouver");
						
						foundVehicle = userInterface.vehicleService.findById(vehicleId);
						
						break;
						
						
					case 7:
						
						System.out.println("\n Suppression de client");
						
						Client del_client = new Client();
						del_client.setId(IOUtils.readInt("Entrez l'Id du client à supprimer"));
						
						List<Reservation> reservationsClient0 = userInterface.reservationService.findResaByClientId(del_client.getId());
						
						for(Reservation reservation : reservationsClient0) {
							
							int donesup = userInterface.reservationService.delete(reservation);
						}
						
						int doneSuppression7 = userInterface.clientService.delete(del_client);
						
						System.out.println("\n Suppression réussie !");
						
						break;
						
					
					case 8:
						
						System.out.println("\n Suppression de vehicule");
						
						Vehicle del_vehicle = new Vehicle();
						del_vehicle.setId(IOUtils.readInt("Entrez l'Id du véhicule à supprimer"));
						
						List<Reservation> reservationsVehicle0 = userInterface.reservationService.findResaByVehicleId(del_vehicle.getId());
						
	
						for(Reservation reservation : reservationsVehicle0) {
							
							int donesup = userInterface.reservationService.delete(reservation);
							
						}
						
						int doneSuppression8 = userInterface.vehicleService.delete(del_vehicle);
						
						System.out.println("\n Suppression réussie !");
						
						break;
						
					
					case 9:
						
						System.out.println("\n Creation d'une Réservation");
						
						Reservation newReservation = new Reservation();
						newReservation.setClient_id(IOUtils.readInt("Entrez l'Id du client pour réservation"));
						newReservation.setVehicle_id(IOUtils.readInt("Entrez l'Id du véhicule à réserver"));
						newReservation.setDebut(IOUtils.readDate("Entrez la date de début de la réservation (dd/MM/yyyy)", true));
						newReservation.setFin(IOUtils.readDate("Entrez la date de fin de la réservation (dd/MM/yyyy)", true));
						int id_reservation = (int) userInterface.reservationService.create(newReservation);
						System.out.println("\nCreation de Reservation terminee, id = " + id_reservation);
						
						break;
						
					
					case 10:
						
						System.out.println("\n La liste des Reservation est:");
						
						List<Reservation> reservations = userInterface.reservationService.findAll();
						
						for(Reservation reservation : reservations ) {
							
							System.out.println(reservation);
						}
						
						break;
						
					
					
					case 11:
						
						System.out.println("\n La liste des réservations pour un client précis:");
						
						int clientId2 = IOUtils.readInt("Entrez l'Id du client concerné ");
						
						List<Reservation> reservationsClient = userInterface.reservationService.findResaByClientId(clientId2);
						
						for(Reservation reservation : reservationsClient ) {
							
							System.out.println(reservation);
						}
						
						break;
						
					
					case 12:
												
						System.out.println("\n La liste des réservations pour un vehicule précis:");
						
						int vehicleId2 = IOUtils.readInt("Entrez l'Id du vehicle concerné ");
						
						List<Reservation> reservationsVehicle = userInterface.reservationService.findResaByVehicleId(vehicleId2);
						
						for(Reservation reservation : reservationsVehicle ) {
							
							System.out.println(reservation);
						}
						
						break;
						
					
					case 13:
						
						System.out.println("\n Suppression de réservation");
						
						Reservation del_reservation = new Reservation();
						
						del_reservation.setId(IOUtils.readInt("Entrez l'Id de la réservation à supprimer"));
						
						int doneSuppression11 = userInterface.reservationService.delete(del_reservation);
						
						System.out.println("\n Suppression réussie !");
						
						break;						
					
					case 14:
						
						System.out.println("\n Update vehicule");
						
						Vehicle updateVehicle = new Vehicle();
						updateVehicle.setConstructeur(IOUtils.readString("Entrez le nom du constructeur", true));
						updateVehicle.setModele(IOUtils.readString("Entrez le modele de la voiture",false));
						updateVehicle.setNb_places(IOUtils.readInt("Entrez le nombre de places"));
						updateVehicle.setId(IOUtils.readInt("Entrez l'id à update"));
						int up = (int) userInterface.vehicleService.update(updateVehicle);
						System.out.println("\n update vehicule terminee, id = " + up);
						break;
						
						
					case 15:
						
						try {
							
							decision = IOUtils.readString("\nVoulez vous vraiment quitter ? o/n ",true).toUpperCase();
							
							System.out.println(decision);
							
							if (decision == "O") {
								
								//if (decision != "N"){
									
									System.out.println("Faite un choix : o pour oui; n pour non !");
								//}
								
							}
							
							else {
								
								System.out.println("Merci au revoir !");
							}
							
							
						}catch(Exception e) {
							
							throw new Exception("Faite un choix : o pour oui; n pour non !", e);
						}
 
						break;
						
					}
					
						
				}
				
			
			}catch(Exception e) {}
			
		}while(choix != 15); //&& decision != "O"
		
				System.out.println("Merci au revoir !");
				//choix = IOUtils.readInt("\nessais");
	}
}
