package com.epf.rentmanager.service;



import java.sql.Date;
import java.util.ArrayList;
import java.util.List;



import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;



import com.epf.rentmanager.dao.ClientDao;
import com.epf.rentmanager.exception.DaoException;
import com.epf.rentmanager.exception.ServiceException;
import com.epf.rentmanager.model.Client;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;




@RunWith(MockitoJUnitRunner.class)



public class ClientServiceTest {
    @InjectMocks
    private ClientService clientService;
    @Mock
    private ClientDao clientDao;

    @Test
    public void findAllTest() throws DaoException, ServiceException {
        List<Client> resultDao = new ArrayList<Client>();
        List<Client> resultService = new ArrayList<Client>();
        Client client1 = new Client(1l,"nom","prenom","test@gmail.com",Date.valueOf("2001-05-09").toLocalDate());
        Client client2 = new Client(2l,"nom","prenom","test@gmail.com",Date.valueOf("2001-05-09").toLocalDate());
        resultDao.add(client1);
        resultDao.add(client2);
        resultService.add(client1);
        resultService.add(client2);



        when(clientDao.findAll()).thenReturn(resultDao);



        assertEquals(resultService, clientService.findAll());
    }

    @Test(expected = DaoException.class)
    public void findAllTestShouldThrow() throws DaoException {


        when(clientDao.findAll()).thenThrow(new DaoException());

        clientService.findAll();
    }
}