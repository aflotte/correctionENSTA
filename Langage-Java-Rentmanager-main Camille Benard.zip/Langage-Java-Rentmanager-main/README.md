# Langage-Java-Rentmanager BENARD Camille
Tp Langage Java

#Difficultés rencontrées

Les premières séances étaient compliquées à suivre du fait que ça se passe en distanciel et que maven et java ont été plus long à s'installer qu'initialement prévu.
De plus, pour les TP 3 & 4, je n'avais plus d'ordinateur fonctionnel, le mien m'ayant subitement lâché, j'ai donc pris du retard sur le développement du TP et je ne pouvais pas poser des questions par rapport à ce que je faisais (vu que je ne pouvais rien faire).
Ayant eu du retard sur les TPs, je n'ai pas réussi à suivre la partie sur les tests.


#Solutions trouvés

Pour les TPs que j'ai passé sans ordinateur, j'écoutais attentivement les problèmes de mes camarades et les réponses des professeurs afin de pouvoir me débloquer si j'avais les mêmes.
Une fois le rythme des TP repris, j'ai dû refaire les premières parties en autonomie ce qui m'a permis de mieux comprendre comment fonctionnaient les méthodes et comment coder dans un Java orienté Web.
Pour la partie sur les tests, j'ai pris le temps de relire en autonomie le cours puis j'ai testé des tests très basiques qui ne serviront surement pas pour l'application Web mais qui m'ont permis de manipuler ces fonctions et de comprendre à quoi elles servaient.


#Choix effectués

Ayant beaucoup travaillée en autonomie, lorsque j'avais un souci ou que je ne connaissais pas une méthode j'allais d'abord relire le cours associé puis, si cela ne suffisait pas, j'allais m'aider de sites internet comme https://stackoverflow.com/ qui m'ont souvent permis de me débloquer seule.


#Commande pour lancer le programme

mvn tomcat7:run
